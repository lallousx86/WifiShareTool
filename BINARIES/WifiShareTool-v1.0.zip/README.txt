WifiShare Tool - v1.0 - by Elias Bachaalany @lallouslab <lallousz-x@yahoo.com>

This tool requires administrative rights to run.